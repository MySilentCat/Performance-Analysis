use std::{thread, time::Duration};

use crate::{RETURN, TRANS_IN, WAKE_UP, WORK};

use super::domain::Book;

pub struct PrinterService;

impl PrinterService {
    pub fn new() -> PrinterService {
        PrinterService
    }

    pub fn print_all(&self, book: &Book) {
        // thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK)); // work
        // thread::sleep(Duration::from_millis(RETURN)); // return
        // println!("Printing all pages of the book");
    }

    pub fn print_pages(&self, book: &Book, start: i32, end: i32) {
        // thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK)); // work
        // thread::sleep(Duration::from_millis(RETURN)); // return
        // println!("Printing pages from {} to {}", start, end);
    }
}
