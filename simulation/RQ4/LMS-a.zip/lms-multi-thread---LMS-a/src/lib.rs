pub struct Object(pub i32);
pub mod components {
    pub mod book_printer;
    pub mod controller;
    pub mod data_component;
    pub mod domain;
    pub mod mapper;
    pub mod service;
    pub mod utils;
}
pub mod thread_pool;
pub static CONTROLLER_PORT: &str = "localhost:5000";
pub static SERVER_PORT: &str = "localhost:5001";
pub static DAO_PORT: &str = "localhost:5002";
pub static PRINTER_PORT: &str = "localhost:5003";
pub static DATABASE_PORT: &str = "localhost:5004";

pub static TRANS_IN: u64 = 100;
pub static WAKE_UP: u64 = 1;
pub static WORK: u64 = 100;
pub static RETURN: u64 = 10;

pub static THREAD_NUM : usize = 1;
pub static people_arr: [(u64, u64); 10] = [(0, 372672359), (1, 745344718), (2, 1118017077), (3, 1490689436), (4, 1863361795), (5, 2236034154), (6, 2608706513), (7, 2981378872), (8, 3354051231), (9, 3726723590)];
// pub static people_arr: [(u64, u64); 10] = [(0, 093168090),(1, 186336179),(2, 279504269),(3, 372672359),(4, 465840449),(5, 559008538),(6, 652176628),(7, 745344718),(8, 838512808),(9, 931680897)];
// pub static people_arr: [(u64, u64); 10] = [(0, 186336179), (1, 372672359), (2, 559008538), (3, 745344718), (4, 931680897), (5, 1118017077), (6, 1304353256), (7, 1490689436), (8, 1677025615), (9, 1863361795)];
pub static arr_space:[u64;10] = [186336179,186336180,186336179,186336180,186336179,186336180,186336179,186336180,186336179,186336180];

