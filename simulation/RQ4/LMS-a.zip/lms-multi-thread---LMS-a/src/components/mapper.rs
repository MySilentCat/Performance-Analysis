use std::{thread, time::Duration};

use reqwest::blocking::Client;

use super::domain::Book;
use crate::{RETURN, TRANS_IN, WAKE_UP, WORK};
pub struct BookMapper;

impl BookMapper {
    pub fn new() -> BookMapper {
        BookMapper
    }

    pub fn create(&self, book: &Book, client: &Client, people: &str) -> i32 {
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        let rsp = client.get("http://localhost:5003/add?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        0
    }

    pub fn delete_by_id(&self, id: String, client: &Client, people: &str) -> i32 {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let rsp = client.get("http://localhost:5003/delete?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        0
    }

    pub fn delete_by_title(&self, title: String, client: &Client, people: &str) -> i32 {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let rsp = client.get("http://localhost:5003/delete?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        0
    }

    pub fn detail(&self, title: String, client: &Client, people: &str) -> Book {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let rsp = client.get("http://localhost:5003/query?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        Book::new("?".to_string(), "?".to_string())
    }

    pub fn query(&self, book: &Book, client: &Client, people: &str) -> Vec<Book> {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let rsp = client.get("http://localhost:5003/query?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        vec![]
    }

    pub fn update(&self, book: &Book, client: &Client, people: &str) -> i32 {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let rsp = client.get("http://localhost:5003/update?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        0
    }
}
