use crate::Object;

pub struct Result {
    pub code: i32,
    pub data: Object,
    pub msg: String,
}

impl Result {
    pub fn fail_1(code: i32, msg: String) -> Result {
        Result {
            code,
            data: Object(0),
            msg,
        }
    }

    pub fn fail_2(msg: String) -> Result {
        Result {
            code: 0,
            data: Object(0),
            msg,
        }
    }

    pub fn get_code(&self) -> i32 {
        self.code
    }

    pub fn get_data(&self) -> &Object {
        &self.data
    }

    pub fn get_msg(&self) -> &String {
        &self.msg
    }

    pub fn ok_1(code: i32, msg: String, data: Object) -> Result {
        Result { code, data, msg }
    }

    pub fn ok_2(msg: String, data: Object) -> Result {
        Result { code: 0, data, msg }
    }

    pub fn ok_3(data: Object) -> Result {
        Result {
            code: 0,
            data,
            msg: String::from("ok"),
        }
    }

    pub fn new_1(code: i32, msg: String) -> Result {
        Result {
            code,
            data: Object(0),
            msg,
        }
    }

    pub fn new_2(code: i32, msg: String, data: Object) -> Result {
        Result { code, data, msg }
    }

    pub fn set_code(&mut self, code: i32) {
        self.code = code;
    }

    pub fn set_msg(&mut self, msg: String) {
        self.msg = msg;
    }
}
