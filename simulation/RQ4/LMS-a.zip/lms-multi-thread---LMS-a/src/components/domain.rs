pub trait User {
    fn get_id(&self) -> &String;
    fn get_name(&self) -> &String;
    fn set_id(&mut self, id: String);
    fn set_name(&mut self, name: String);
}

pub struct Student {
    id: String,
    name: String,
    grade: i32,
}

impl User for Student {
    fn get_id(&self) -> &String {
        &self.id
    }

    fn get_name(&self) -> &String {
        &self.name
    }

    fn set_id(&mut self, id: String) {
        self.id = id;
    }

    fn set_name(&mut self, name: String) {
        self.name = name;
    }
}

impl Student {
    pub fn new(id: String, name: String, grade: i32) -> Student {
        Student { id, name, grade }
    }

    pub fn get_grade(&self) -> i32 {
        self.grade
    }

    pub fn set_grade(&mut self, grade: i32) {
        self.grade = grade;
    }
}

pub struct Librarian {
    id: String,
    name: String,
    office: i32,
}

impl User for Librarian {
    fn get_id(&self) -> &String {
        &self.id
    }

    fn get_name(&self) -> &String {
        &self.name
    }

    fn set_id(&mut self, id: String) {
        self.id = id;
    }

    fn set_name(&mut self, name: String) {
        self.name = name;
    }
}

impl Librarian {
    pub fn new(id: String, name: String, office: i32) -> Librarian {
        Librarian { id, name, office }
    }

    pub fn get_office(&self) -> i32 {
        self.office
    }

    pub fn set_office(&mut self, office: i32) {
        self.office = office;
    }
}

#[derive(Clone)]
pub struct Book {
    author: String,
    content: Vec<String>,
    id: String,
    loaction: String,
    title: String,
}

impl Book {
    pub fn new(id: String, title: String) -> Book {
        Book {
            author: "".to_string(),
            content: vec![],
            id,
            loaction: "".to_string(),
            title,
        }
    }

    pub fn get_author(&self) -> &String {
        &self.author
    }

    pub fn get_content(&self) -> &Vec<String> {
        &self.content
    }

    pub fn get_id(&self) -> &String {
        &self.id
    }

    pub fn get_location(&self) -> &String {
        &self.loaction
    }

    pub fn get_title(&self) -> &String {
        &self.title
    }

    pub fn set_author(&mut self, author: String) {
        self.author = author;
    }

    pub fn set_content(&mut self, content: Vec<String>) {
        self.content = content;
    }

    pub fn set_id(&mut self, id: String) {
        self.id = id;
    }

    pub fn set_location(&mut self, location: String) {
        self.loaction = location;
    }

    pub fn set_title(&mut self, title: String) {
        self.title = title;
    }
}
