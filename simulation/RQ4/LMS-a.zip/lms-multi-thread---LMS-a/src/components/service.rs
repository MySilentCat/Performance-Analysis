use std::{collections::HashMap, io::Write, net::{TcpStream, UdpSocket}, thread, time::Duration};

use reqwest::blocking::Client;

pub use super::{domain::Book, mapper::BookMapper};
use crate::{RETURN, TRANS_IN, WAKE_UP, WORK};
pub struct BookService;

impl BookService {
    pub fn new() -> BookService {
        BookService
    }

    pub fn create(&self, book: &Book, client: &Client, people: &str) -> i32 {
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        let rsp = client.get("http://localhost:5002/create?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN)); // return
        0
    }

    pub fn delete_by_id(&self, id: String, client: &Client, people: &str) -> i32 {
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        let rsp = client.get("http://localhost:5002/delete_by_id?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        0
    }

    pub fn delete_by_title(&self, title: String, client: &Client, people: &str) -> i32 {
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        let rsp = client.get("http://localhost:5002/delete_by_title?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        0
    }

    pub fn detail(&self, title: String, client: &Client, people: &str) -> Book {
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        let rsp = client.get("http://localhost:5002/detail?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        Book::new("?".to_string(), "?".to_string())
    }

    pub fn print_all(&self, book: &Book, client: &Client, people: &str) {
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        let rsp = client.get("http://localhost:5004/print_all?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        // println!("Printing all pages of the book?".to_owned() + people);
    }

    pub fn print_pages(&self, book: &Book, start: i32, end: i32, client: &Client, people: &str) {
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        let rsp = client.get("http://localhost:5004/print_pages?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        // println!("Printing pages from {} to {}", start, end);
    }

    pub fn query(&self, book: &Book, client: &Client, people: &str) -> HashMap<String, Book> {
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        let rsp = client.get("http://localhost:5002/query?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        HashMap::new()
    }

    pub fn update(&self, book: &Book, client: &Client, people: &str) -> i32 {
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        let rsp = client.get("http://localhost:5002/update?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        0
    }

    pub fn read_file(&self, path: String, people: &str) -> Vec<u8> {
        // thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK)); // work
        let people = people.to_owned();
        thread::spawn(move || {
            thread::sleep(Duration::from_millis(RETURN)); // return
            let mut stream = TcpStream::connect("127.0.0.1:4999").unwrap();
            stream.write(people.as_bytes()).unwrap();
        });
        vec![]
    }

    pub fn read_picture(&self, path: String, people: &str) -> Vec<u8> {
        // thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK)); // work
        // thread::sleep(Duration::from_millis(RETURN)); // return
        vec![]
    }

}
