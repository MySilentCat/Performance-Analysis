use std::sync::Arc;
use std::thread;
use std::time::{self, Duration};

use rand::rngs::StdRng;
use rand::Rng;
use reqwest::blocking::Client;

use crate::Object;
use crate::{RETURN, TRANS_IN, WAKE_UP, WORK};
use super::domain::Book;
use super::utils::Result;
#[derive(Clone, Copy)]
pub struct BookController;

impl BookController {
    pub fn new() -> BookController {
        BookController
    }

    pub fn create(&self, book: &Book, client: &Client, people: &str) -> Result {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let _ = client.get("http://localhost:5001/create?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        Result::ok_3(Object(0))
    }

    pub fn delete_by_id(&self, id: String, client: &Client, people: &str) -> Result {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let _ = client.get("http://localhost:5001/delete_by_id?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        Result::ok_3(Object(0))
    }

    pub fn delete_by_title(&self, id: String, client: &Client, people: &str) -> Result {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let _ = client.get("http://localhost:5001/delete_by_title?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        Result::ok_3(Object(0))
    }


    pub fn detail(&self, title: String, client: &Client, people: &str) -> Result {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let rsp = client.get("http://localhost:5001/detail?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        Result::ok_3(Object(0))
    }

    pub fn query(&self, book: &Book, client: &Client, people: &str) -> Result {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let rsp = client.get("http://localhost:5001/query?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        Result::ok_3(Object(0))
    }

    pub fn update(&self, book: &Book, client: &Client, people: &str) -> Result {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let rsp = client.get("http://localhost:5001/update?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
        Result::ok_3(Object(0))
    }

    pub fn print_pages(&self, book: &Book, client: &Client, people: &str) {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let rsp = client.get("http://localhost:5001/print_pages?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
    }

    pub fn print_all(&self, book: &Book, client: &Client, people: &str) {
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK));
        thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        let rsp = client.get("http://localhost:5001/print_all?".to_owned() + people).send();
        thread::sleep(Duration::from_millis(RETURN));
    }

    

    pub fn download(&self, title: String, client: &Client, people: &str) -> Vec<u8> {
        let c1 = client.clone();
        let c2  = client.clone();
        let p1 = Arc::new(people.to_owned());
        let p2 = Arc::new(people.to_owned());
        let handle1 = thread::spawn(move || {
            thread::sleep(Duration::from_millis(WAKE_UP)); //wake-up
            thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
            let rsp = c1.get("http://localhost:5001/read_file?".to_owned() + &p1).send();
            thread::sleep(Duration::from_millis(RETURN));
        });
        let handle2 = thread::spawn(move || {
            thread::sleep(Duration::from_millis(WAKE_UP)); //wake-up
            thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
            let rsp = c2.get("http://localhost:5001/read_picture?".to_owned() + &p2).send();
            thread::sleep(Duration::from_millis(RETURN));
        });
        handle1.join().unwrap();
        handle2.join().unwrap();
        vec![]
    }


}
