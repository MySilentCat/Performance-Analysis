use std::{thread, time::Duration};

use crate::Object;
use crate::{RETURN, TRANS_IN, WAKE_UP, WORK};
pub struct DataBase;

impl DataBase {
    pub fn new() -> DataBase {
        DataBase
    }

    pub fn add(&self, sql: &str) -> i32 {
        // thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK)); // work
        // thread::sleep(Duration::from_millis(RETURN)); // return
        0
    }

    pub fn delete(&self, sql: &str) -> i32 {
        // thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK)); // work
        // thread::sleep(Duration::from_millis(RETURN)); // return
        0
    }

    pub fn update(&self, sql: &str) -> Object {
        // thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK)); // work
        // thread::sleep(Duration::from_millis(RETURN)); // return
        Object(0)
    }

    pub fn query(&self, sql: &str) -> Object {
        // thread::sleep(Duration::from_micros(TRANS_IN)); // trans-in
        thread::sleep(Duration::from_millis(WAKE_UP)); // wake-up
        thread::sleep(Duration::from_millis(WORK)); // work
        // thread::sleep(Duration::from_millis(RETURN)); // return
        Object(0)
    }
}
